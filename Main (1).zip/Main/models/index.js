const Trip = require('./Trip');

module.exports = { Trip };
